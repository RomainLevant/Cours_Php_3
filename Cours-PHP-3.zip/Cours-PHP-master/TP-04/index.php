<?php
// Ajouter votre réponse sur le formulaire :
// https://forms.gle/TxhzmpEx3oW67aBf7

// Création de deux tables
// - users 
// - articles 

// Champs de la table Users
// --
// id
// firstname
// lastname
// email
// password

// Champs de la table Articles
// --
// id
// title
// content
// read_counter
