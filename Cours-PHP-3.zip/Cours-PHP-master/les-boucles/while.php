<?php

// for ($i = 1; $i <= 10; $i++) 
// {
//     echo $i ."<br>";
// }

// Initialisation
$i = 100;

// Boucle tant que la condition est vraie
while ($i <= 20)
{
    echo $i ."<br>";

    // Incrémentation
    $i++;
}


// echo "<hr>";

// $isOk = true;
// $j = 1;

// while ($isOk)
// {
//     echo $j++ . "<br>";

//     if ($j > 10) $isOk = false;
// }