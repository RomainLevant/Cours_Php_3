<?php

// for (initialisation; condition de bouclage; incrémentation) 
for ($i = 1; $i <= 10; $i++) 
{
    echo $i ."<br>";
}
