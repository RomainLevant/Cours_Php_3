<?php

// Definition des paramètres de connexion BDD
$db_type = "mysql";         // Type de la BDD / Type du SGBD
$db_host = "127.0.0.1";     // Adresse du serveur de BDD
$db_port = "3306";          // Port de la BDD
$db_schema = "cours_sql";   // Nom de la BDD / Nom du schema de données
$db_charset = "utf8";       // Jeu de caratères utilisé pour les données
$db_user = "osw3";          // Nom d'utilisateur de la BDD
$db_pass = "myosw3sql";     // Mot de passe de l'utilisateur de la BDD
